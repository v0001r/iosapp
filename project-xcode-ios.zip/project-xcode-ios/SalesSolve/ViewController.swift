//
//  ViewController.swift
//  SalesSolve
//
//  Created by Eashan on 1/8/19.
//  Copyright © 2019 Sales Solve. All rights reserved.
//

import UIKit
import WebKit

class ViewController: UIViewController {
    
    @IBOutlet weak var webView: WKWebView!
    @IBOutlet weak var activity: UIActivityIndicatorView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadWebsite()
    }
    
    private func loadWebsite() {
        let webURL = URL(string: "https://support.salessolve.com/authentication/login")
        let requestURL = URLRequest(url: webURL!)
        webView.load(requestURL)
    }
}

